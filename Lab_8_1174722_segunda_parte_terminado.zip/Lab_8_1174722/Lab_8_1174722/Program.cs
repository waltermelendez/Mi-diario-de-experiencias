﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_8_1174722
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingrese su nombre ");
            String nombre = Console.ReadLine();

            Console.WriteLine("Bienvenido " + nombre);

            Console.WriteLine("Que numero de fibonacci desea?");
            int numero = int.Parse(Console.ReadLine());

            if (numero <= 0)
            {
                Console.WriteLine("Ese numero de fibonacci no existe");

            }
            else
            {
                if (numero == 1)
                {
                    Console.WriteLine(0);
                }
                else if (numero == 2)
                {
                    Console.WriteLine(1);
                }
                else {
                    int resultado = 0;
                    int numeroAnterior1 = 0;
                    int numeroAnterior2 = 1;
                    for (int i = 3; i < numero; i++)
                    {
                        resultado = numeroAnterior1 + numeroAnterior2;
                        numeroAnterior1 = numeroAnterior2;
                        numeroAnterior2 = resultado;
                    }
                    Console.WriteLine(resultado);
                }
               
            }
            Console.ReadKey();
        }
    }
}
