﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_8_1174722_segunda_parte
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingrese un numero");
                int numero = int.Parse(Console.ReadLine());
            while (numero > 18) { 
            Console.WriteLine("aun estas a salvo");
                Console.WriteLine("Ingresa otro numero");

                numero= int.Parse(Console.ReadLine());
                Console.WriteLine("Veamos...");
            }
            Console.WriteLine("Ya no estas a salvo");
            Console.ReadKey();

            do
            {
                Console.WriteLine("Este es un do while");
               
            }while(numero > 18);
               
            

            Console.ReadKey();
        }
    }
}
