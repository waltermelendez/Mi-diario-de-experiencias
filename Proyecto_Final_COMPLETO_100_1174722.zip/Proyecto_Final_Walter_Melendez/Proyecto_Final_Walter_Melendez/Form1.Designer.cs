﻿namespace Proyecto_Final_Walter_Melendez
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.Inico = new System.Windows.Forms.TabPage();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.lbl_nick2 = new System.Windows.Forms.Label();
            this.Txt_nombre2 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.Txt_equipo2 = new System.Windows.Forms.TextBox();
            this.Btn_nickanme2 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Txt_nombre = new System.Windows.Forms.TextBox();
            this.txt_equipo = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btn_Nicname1 = new System.Windows.Forms.Button();
            this.lbl_nick1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.Mazo_p1 = new System.Windows.Forms.TabPage();
            this.lbl_mazos_p2 = new System.Windows.Forms.Label();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.label51 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btn_revelion = new System.Windows.Forms.Button();
            this.lbl_DT1_1 = new System.Windows.Forms.Label();
            this.lblalcance_mazo_1_1 = new System.Windows.Forms.Label();
            this.lbl_VTmazo1_1 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.CP_1_1 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btn_boys = new System.Windows.Forms.Button();
            this.lbl_AlcanceMazo1_2 = new System.Windows.Forms.Label();
            this.lbl_VTMazo1_2 = new System.Windows.Forms.Label();
            this.CP_1_2 = new System.Windows.Forms.Label();
            this.lbl_DTMazo1_2 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.Mazos_p2 = new System.Windows.Forms.TabPage();
            this.lbl_p1_M = new System.Windows.Forms.Label();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.label83 = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.label89 = new System.Windows.Forms.Label();
            this.label90 = new System.Windows.Forms.Label();
            this.label91 = new System.Windows.Forms.Label();
            this.label92 = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.label95 = new System.Windows.Forms.Label();
            this.label96 = new System.Windows.Forms.Label();
            this.label97 = new System.Windows.Forms.Label();
            this.label98 = new System.Windows.Forms.Label();
            this.label99 = new System.Windows.Forms.Label();
            this.label100 = new System.Windows.Forms.Label();
            this.label101 = new System.Windows.Forms.Label();
            this.label102 = new System.Windows.Forms.Label();
            this.label103 = new System.Windows.Forms.Label();
            this.label104 = new System.Windows.Forms.Label();
            this.label105 = new System.Windows.Forms.Label();
            this.label106 = new System.Windows.Forms.Label();
            this.label107 = new System.Windows.Forms.Label();
            this.label108 = new System.Windows.Forms.Label();
            this.label109 = new System.Windows.Forms.Label();
            this.label110 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btn_esqueletos = new System.Windows.Forms.Button();
            this.lblalcance4 = new System.Windows.Forms.Label();
            this.cp_4 = new System.Windows.Forms.Label();
            this.lbl_vida4 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.lbl_danio4 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btn_helado = new System.Windows.Forms.Button();
            this.lbl_alcancemazo2_1 = new System.Windows.Forms.Label();
            this.CP_2_1 = new System.Windows.Forms.Label();
            this.Lbl_vidaMazo2_1 = new System.Windows.Forms.Label();
            this.lbl_DTMazo2_1 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.Enfrentamiento_ = new System.Windows.Forms.TabPage();
            this.label62 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.Ganador = new System.Windows.Forms.Label();
            this.total_p1 = new System.Windows.Forms.Label();
            this.total_P2 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.lbl_PuntoC1 = new System.Windows.Forms.Label();
            this.lblfrenteC = new System.Windows.Forms.Label();
            this.lblfrenteC2 = new System.Windows.Forms.Label();
            this.lbl_PuntoC2 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.lbl_PuntoAl1 = new System.Windows.Forms.Label();
            this.lbl_PuntoV1 = new System.Windows.Forms.Label();
            this.btnEmpezar = new System.Windows.Forms.Button();
            this.lblfrenteAl1 = new System.Windows.Forms.Label();
            this.lblfrenteV1 = new System.Windows.Forms.Label();
            this.lblfrenteAl2 = new System.Windows.Forms.Label();
            this.lblfrenteV2 = new System.Windows.Forms.Label();
            this.lbl_PuntoAl2 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.lbl_PuntoM1 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.lbl_PuntoV2 = new System.Windows.Forms.Label();
            this.lblfrenteM1 = new System.Windows.Forms.Label();
            this.lblfrenteM2 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.lbl_PuntoM2 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.Lblmazo_P1 = new System.Windows.Forms.Label();
            this.lbl_mazo_P2 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.lbl_frente2 = new System.Windows.Forms.Label();
            this.lbl_frente1 = new System.Windows.Forms.Label();
            this.btn_limpiar = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.Inico.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.Mazo_p1.SuspendLayout();
            this.groupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.Mazos_p2.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.Enfrentamiento_.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.Inico);
            this.tabControl1.Controls.Add(this.Mazo_p1);
            this.tabControl1.Controls.Add(this.Mazos_p2);
            this.tabControl1.Controls.Add(this.Enfrentamiento_);
            this.tabControl1.Font = new System.Drawing.Font("Franklin Gothic Demi", 7.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1440, 770);
            this.tabControl1.TabIndex = 0;
            // 
            // Inico
            // 
            this.Inico.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.Inico.Controls.Add(this.groupBox5);
            this.Inico.Controls.Add(this.groupBox6);
            this.Inico.Controls.Add(this.label6);
            this.Inico.Location = new System.Drawing.Point(4, 26);
            this.Inico.Name = "Inico";
            this.Inico.Padding = new System.Windows.Forms.Padding(3);
            this.Inico.Size = new System.Drawing.Size(1432, 740);
            this.Inico.TabIndex = 0;
            this.Inico.Text = "Registro";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label3);
            this.groupBox5.Controls.Add(this.lbl_nick2);
            this.groupBox5.Controls.Add(this.Txt_nombre2);
            this.groupBox5.Controls.Add(this.label8);
            this.groupBox5.Controls.Add(this.Txt_equipo2);
            this.groupBox5.Controls.Add(this.Btn_nickanme2);
            this.groupBox5.Controls.Add(this.label4);
            this.groupBox5.Font = new System.Drawing.Font("Franklin Gothic Medium", 7.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.groupBox5.Location = new System.Drawing.Point(46, 161);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(414, 307);
            this.groupBox5.TabIndex = 20;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Jugador 1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(74, 69);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 17);
            this.label3.TabIndex = 6;
            this.label3.Text = "Nombre";
            // 
            // lbl_nick2
            // 
            this.lbl_nick2.AutoSize = true;
            this.lbl_nick2.Location = new System.Drawing.Point(211, 179);
            this.lbl_nick2.Name = "lbl_nick2";
            this.lbl_nick2.Size = new System.Drawing.Size(21, 17);
            this.lbl_nick2.TabIndex = 7;
            this.lbl_nick2.Text = "\" \"";
            // 
            // Txt_nombre2
            // 
            this.Txt_nombre2.Location = new System.Drawing.Point(214, 69);
            this.Txt_nombre2.Name = "Txt_nombre2";
            this.Txt_nombre2.Size = new System.Drawing.Size(100, 22);
            this.Txt_nombre2.TabIndex = 14;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(74, 179);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(64, 17);
            this.label8.TabIndex = 5;
            this.label8.Text = "Nickname";
            // 
            // Txt_equipo2
            // 
            this.Txt_equipo2.Location = new System.Drawing.Point(214, 127);
            this.Txt_equipo2.Name = "Txt_equipo2";
            this.Txt_equipo2.Size = new System.Drawing.Size(100, 22);
            this.Txt_equipo2.TabIndex = 12;
            // 
            // Btn_nickanme2
            // 
            this.Btn_nickanme2.BackColor = System.Drawing.Color.Ivory;
            this.Btn_nickanme2.ForeColor = System.Drawing.Color.DarkViolet;
            this.Btn_nickanme2.Location = new System.Drawing.Point(202, 251);
            this.Btn_nickanme2.Name = "Btn_nickanme2";
            this.Btn_nickanme2.Size = new System.Drawing.Size(75, 23);
            this.Btn_nickanme2.TabIndex = 16;
            this.Btn_nickanme2.Text = "Nombrar";
            this.Btn_nickanme2.UseVisualStyleBackColor = false;
            this.Btn_nickanme2.Click += new System.EventHandler(this.Btn_nickanme2_Click_1);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(74, 124);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 17);
            this.label4.TabIndex = 4;
            this.label4.Text = "Equipo";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.label1);
            this.groupBox6.Controls.Add(this.Txt_nombre);
            this.groupBox6.Controls.Add(this.txt_equipo);
            this.groupBox6.Controls.Add(this.label2);
            this.groupBox6.Controls.Add(this.label5);
            this.groupBox6.Controls.Add(this.btn_Nicname1);
            this.groupBox6.Controls.Add(this.lbl_nick1);
            this.groupBox6.Font = new System.Drawing.Font("Franklin Gothic Medium", 7.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox6.ForeColor = System.Drawing.Color.Red;
            this.groupBox6.Location = new System.Drawing.Point(923, 161);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(414, 307);
            this.groupBox6.TabIndex = 20;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Jugador 2";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(79, 69);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 17);
            this.label1.TabIndex = 11;
            this.label1.Text = "Nombre";
            // 
            // Txt_nombre
            // 
            this.Txt_nombre.Location = new System.Drawing.Point(203, 63);
            this.Txt_nombre.Name = "Txt_nombre";
            this.Txt_nombre.Size = new System.Drawing.Size(100, 22);
            this.Txt_nombre.TabIndex = 15;
            // 
            // txt_equipo
            // 
            this.txt_equipo.Location = new System.Drawing.Point(203, 121);
            this.txt_equipo.Name = "txt_equipo";
            this.txt_equipo.Size = new System.Drawing.Size(100, 22);
            this.txt_equipo.TabIndex = 13;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(79, 124);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 17);
            this.label2.TabIndex = 8;
            this.label2.Text = "Equipo";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(79, 176);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(64, 17);
            this.label5.TabIndex = 10;
            this.label5.Text = "Nickname";
            // 
            // btn_Nicname1
            // 
            this.btn_Nicname1.BackColor = System.Drawing.Color.Ivory;
            this.btn_Nicname1.ForeColor = System.Drawing.Color.DarkViolet;
            this.btn_Nicname1.Location = new System.Drawing.Point(214, 248);
            this.btn_Nicname1.Name = "btn_Nicname1";
            this.btn_Nicname1.Size = new System.Drawing.Size(75, 23);
            this.btn_Nicname1.TabIndex = 17;
            this.btn_Nicname1.Text = "Nombrar";
            this.btn_Nicname1.UseVisualStyleBackColor = false;
            this.btn_Nicname1.Click += new System.EventHandler(this.btn_Nicname1_Click_1);
            // 
            // lbl_nick1
            // 
            this.lbl_nick1.AutoSize = true;
            this.lbl_nick1.Location = new System.Drawing.Point(211, 176);
            this.lbl_nick1.Name = "lbl_nick1";
            this.lbl_nick1.Size = new System.Drawing.Size(21, 17);
            this.lbl_nick1.TabIndex = 9;
            this.lbl_nick1.Text = "\" \"";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(482, 37);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(313, 43);
            this.label6.TabIndex = 18;
            this.label6.Text = "Registro de jugadores";
            // 
            // Mazo_p1
            // 
            this.Mazo_p1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.Mazo_p1.Controls.Add(this.lbl_mazos_p2);
            this.Mazo_p1.Controls.Add(this.groupBox8);
            this.Mazo_p1.Controls.Add(this.pictureBox2);
            this.Mazo_p1.Controls.Add(this.pictureBox1);
            this.Mazo_p1.Controls.Add(this.groupBox2);
            this.Mazo_p1.Controls.Add(this.groupBox1);
            this.Mazo_p1.Controls.Add(this.label7);
            this.Mazo_p1.Location = new System.Drawing.Point(4, 26);
            this.Mazo_p1.Name = "Mazo_p1";
            this.Mazo_p1.Padding = new System.Windows.Forms.Padding(3);
            this.Mazo_p1.Size = new System.Drawing.Size(1432, 740);
            this.Mazo_p1.TabIndex = 1;
            this.Mazo_p1.Text = "Mazo_P1";
            // 
            // lbl_mazos_p2
            // 
            this.lbl_mazos_p2.AutoSize = true;
            this.lbl_mazos_p2.Font = new System.Drawing.Font("Franklin Gothic Medium", 7.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_mazos_p2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lbl_mazos_p2.Location = new System.Drawing.Point(172, 15);
            this.lbl_mazos_p2.Name = "lbl_mazos_p2";
            this.lbl_mazos_p2.Size = new System.Drawing.Size(21, 17);
            this.lbl_mazos_p2.TabIndex = 6;
            this.lbl_mazos_p2.Text = "\" \"";
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.label51);
            this.groupBox8.Controls.Add(this.label55);
            this.groupBox8.Controls.Add(this.label47);
            this.groupBox8.Controls.Add(this.label50);
            this.groupBox8.Controls.Add(this.label54);
            this.groupBox8.Controls.Add(this.label45);
            this.groupBox8.Controls.Add(this.label31);
            this.groupBox8.Controls.Add(this.label41);
            this.groupBox8.Controls.Add(this.label40);
            this.groupBox8.Controls.Add(this.label28);
            this.groupBox8.Controls.Add(this.label56);
            this.groupBox8.Controls.Add(this.label35);
            this.groupBox8.Controls.Add(this.label48);
            this.groupBox8.Controls.Add(this.label34);
            this.groupBox8.Controls.Add(this.label30);
            this.groupBox8.Controls.Add(this.label29);
            this.groupBox8.Controls.Add(this.label33);
            this.groupBox8.Controls.Add(this.label32);
            this.groupBox8.Controls.Add(this.label53);
            this.groupBox8.Controls.Add(this.label49);
            this.groupBox8.Controls.Add(this.label43);
            this.groupBox8.Controls.Add(this.label52);
            this.groupBox8.Controls.Add(this.label46);
            this.groupBox8.Controls.Add(this.label42);
            this.groupBox8.Controls.Add(this.label44);
            this.groupBox8.Controls.Add(this.label39);
            this.groupBox8.Controls.Add(this.label38);
            this.groupBox8.Controls.Add(this.label37);
            this.groupBox8.Font = new System.Drawing.Font("Franklin Gothic Medium", 7.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox8.Location = new System.Drawing.Point(427, 486);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(498, 210);
            this.groupBox8.TabIndex = 5;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Leyenda";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(392, 172);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(101, 34);
            this.label51.TabIndex = 6;
            this.label51.Text = "menor que 2.4 o\r\n mayor que 4.3";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(217, 171);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(59, 17);
            this.label55.TabIndex = 6;
            this.label55.Text = "3.1 a 3.5";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(309, 171);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(59, 17);
            this.label47.TabIndex = 6;
            this.label47.Text = "3.6 a 4.3";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(392, 137);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(88, 17);
            this.label50.TabIndex = 6;
            this.label50.Text = "menor que 10";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(217, 136);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(53, 17);
            this.label54.TabIndex = 6;
            this.label54.Text = "15 a 25";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(309, 136);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(53, 17);
            this.label45.TabIndex = 6;
            this.label45.Text = "10 a 15";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(388, 19);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(36, 17);
            this.label31.TabIndex = 4;
            this.label31.Text = "Rojo:";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(309, 102);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(85, 17);
            this.label41.TabIndex = 6;
            this.label41.Text = "2000 a 2500";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(94, 102);
            this.label40.Name = "label40";
            this.label40.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label40.Size = new System.Drawing.Size(103, 17);
            this.label40.TabIndex = 6;
            this.label40.Text = "mayor que 3000";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(111, 18);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(44, 17);
            this.label28.TabIndex = 4;
            this.label28.Text = "Verde:";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(209, 102);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(85, 17);
            this.label56.TabIndex = 6;
            this.label56.Text = "2500 a 3000";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.ForeColor = System.Drawing.Color.Maroon;
            this.label35.Location = new System.Drawing.Point(392, 44);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(33, 17);
            this.label35.TabIndex = 4;
            this.label35.Text = "Bajo";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(392, 102);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(104, 17);
            this.label48.TabIndex = 6;
            this.label48.Text = "menor que 2000";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.ForeColor = System.Drawing.Color.Olive;
            this.label34.Location = new System.Drawing.Point(309, 43);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(54, 17);
            this.label34.TabIndex = 4;
            this.label34.Text = "Decente";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(301, 18);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(58, 17);
            this.label30.TabIndex = 4;
            this.label30.Text = "Amarillo:";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(206, 18);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(75, 17);
            this.label29.TabIndex = 4;
            this.label29.Text = "Verde claro:";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.ForeColor = System.Drawing.Color.Lime;
            this.label33.Location = new System.Drawing.Point(206, 43);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(64, 17);
            this.label33.TabIndex = 4;
            this.label33.Text = "Aceptable";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.ForeColor = System.Drawing.Color.Green;
            this.label32.Location = new System.Drawing.Point(94, 43);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(75, 17);
            this.label32.TabIndex = 4;
            this.label32.Text = "Inmejorable";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(392, 69);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(104, 17);
            this.label53.TabIndex = 6;
            this.label53.Text = "menor que 2500";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(209, 69);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(85, 17);
            this.label49.TabIndex = 6;
            this.label49.Text = "3000 a 4000";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(309, 69);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(85, 17);
            this.label43.TabIndex = 6;
            this.label43.Text = "2500 a 3000";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(22, 102);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(37, 17);
            this.label52.TabIndex = 6;
            this.label52.Text = "Daño";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(94, 171);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(76, 17);
            this.label46.TabIndex = 6;
            this.label46.Text = "de 2.4 a 3.0";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(94, 69);
            this.label42.Name = "label42";
            this.label42.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label42.Size = new System.Drawing.Size(103, 17);
            this.label42.TabIndex = 6;
            this.label42.Text = "mayor que 4000";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(91, 136);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(87, 17);
            this.label44.TabIndex = 6;
            this.label44.Text = "mayor que 25";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(22, 171);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(39, 17);
            this.label39.TabIndex = 5;
            this.label39.Text = "Costo";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(22, 136);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(52, 17);
            this.label38.TabIndex = 5;
            this.label38.Text = "Alcance";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(22, 69);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(32, 17);
            this.label37.TabIndex = 5;
            this.label37.Text = "Vida";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Proyecto_Final_Walter_Melendez.Properties.Resources.Rebelion_en_la_granja;
            this.pictureBox2.Location = new System.Drawing.Point(44, 34);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(501, 321);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox2.TabIndex = 3;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Proyecto_Final_Walter_Melendez.Properties.Resources.The_boys;
            this.pictureBox1.Location = new System.Drawing.Point(767, 34);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(509, 315);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btn_revelion);
            this.groupBox2.Controls.Add(this.lbl_DT1_1);
            this.groupBox2.Controls.Add(this.lblalcance_mazo_1_1);
            this.groupBox2.Controls.Add(this.lbl_VTmazo1_1);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.CP_1_1);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Font = new System.Drawing.Font("Franklin Gothic Medium", 7.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.groupBox2.Location = new System.Drawing.Point(22, 486);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(384, 210);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Rebalión en la granja";
            // 
            // btn_revelion
            // 
            this.btn_revelion.BackColor = System.Drawing.Color.Ivory;
            this.btn_revelion.ForeColor = System.Drawing.Color.DarkViolet;
            this.btn_revelion.Location = new System.Drawing.Point(285, 37);
            this.btn_revelion.Name = "btn_revelion";
            this.btn_revelion.Size = new System.Drawing.Size(75, 38);
            this.btn_revelion.TabIndex = 4;
            this.btn_revelion.Text = "Elegir";
            this.btn_revelion.UseVisualStyleBackColor = false;
            this.btn_revelion.Click += new System.EventHandler(this.btn_revelion_Click);
            // 
            // lbl_DT1_1
            // 
            this.lbl_DT1_1.AutoSize = true;
            this.lbl_DT1_1.Location = new System.Drawing.Point(205, 43);
            this.lbl_DT1_1.Name = "lbl_DT1_1";
            this.lbl_DT1_1.Size = new System.Drawing.Size(21, 17);
            this.lbl_DT1_1.TabIndex = 3;
            this.lbl_DT1_1.Text = "\" \"";
            // 
            // lblalcance_mazo_1_1
            // 
            this.lblalcance_mazo_1_1.AutoSize = true;
            this.lblalcance_mazo_1_1.Location = new System.Drawing.Point(205, 169);
            this.lblalcance_mazo_1_1.Name = "lblalcance_mazo_1_1";
            this.lblalcance_mazo_1_1.Size = new System.Drawing.Size(51, 17);
            this.lblalcance_mazo_1_1.TabIndex = 3;
            this.lblalcance_mazo_1_1.Text = "label34";
            // 
            // lbl_VTmazo1_1
            // 
            this.lbl_VTmazo1_1.AutoSize = true;
            this.lbl_VTmazo1_1.Location = new System.Drawing.Point(205, 83);
            this.lbl_VTmazo1_1.Name = "lbl_VTmazo1_1";
            this.lbl_VTmazo1_1.Size = new System.Drawing.Size(51, 17);
            this.lbl_VTmazo1_1.TabIndex = 3;
            this.lbl_VTmazo1_1.Text = "label34";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(32, 128);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(99, 17);
            this.label13.TabIndex = 1;
            this.label13.Text = "Costo promedio:";
            // 
            // CP_1_1
            // 
            this.CP_1_1.AutoSize = true;
            this.CP_1_1.Location = new System.Drawing.Point(205, 131);
            this.CP_1_1.Name = "CP_1_1";
            this.CP_1_1.Size = new System.Drawing.Size(51, 17);
            this.CP_1_1.TabIndex = 3;
            this.CP_1_1.Text = "label34";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(32, 44);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(121, 17);
            this.label14.TabIndex = 1;
            this.label14.Text = "Daño total del mazo:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(32, 166);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(108, 17);
            this.label15.TabIndex = 1;
            this.label15.Text = "Alcance del mazo:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(32, 82);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(116, 17);
            this.label16.TabIndex = 1;
            this.label16.Text = "Vida total del mazo:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btn_boys);
            this.groupBox1.Controls.Add(this.lbl_AlcanceMazo1_2);
            this.groupBox1.Controls.Add(this.lbl_VTMazo1_2);
            this.groupBox1.Controls.Add(this.CP_1_2);
            this.groupBox1.Controls.Add(this.lbl_DTMazo1_2);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Font = new System.Drawing.Font("Franklin Gothic Medium", 7.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.groupBox1.Location = new System.Drawing.Point(968, 486);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(436, 210);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "The Boys";
            // 
            // btn_boys
            // 
            this.btn_boys.BackColor = System.Drawing.Color.Ivory;
            this.btn_boys.ForeColor = System.Drawing.Color.DarkViolet;
            this.btn_boys.Location = new System.Drawing.Point(329, 41);
            this.btn_boys.Name = "btn_boys";
            this.btn_boys.Size = new System.Drawing.Size(75, 36);
            this.btn_boys.TabIndex = 4;
            this.btn_boys.Text = "Elegir";
            this.btn_boys.UseVisualStyleBackColor = false;
            this.btn_boys.Click += new System.EventHandler(this.btn_boys_Click);
            // 
            // lbl_AlcanceMazo1_2
            // 
            this.lbl_AlcanceMazo1_2.AutoSize = true;
            this.lbl_AlcanceMazo1_2.Location = new System.Drawing.Point(211, 166);
            this.lbl_AlcanceMazo1_2.Name = "lbl_AlcanceMazo1_2";
            this.lbl_AlcanceMazo1_2.Size = new System.Drawing.Size(51, 17);
            this.lbl_AlcanceMazo1_2.TabIndex = 3;
            this.lbl_AlcanceMazo1_2.Text = "label34";
            // 
            // lbl_VTMazo1_2
            // 
            this.lbl_VTMazo1_2.AutoSize = true;
            this.lbl_VTMazo1_2.Location = new System.Drawing.Point(211, 82);
            this.lbl_VTMazo1_2.Name = "lbl_VTMazo1_2";
            this.lbl_VTMazo1_2.Size = new System.Drawing.Size(51, 17);
            this.lbl_VTMazo1_2.TabIndex = 3;
            this.lbl_VTMazo1_2.Text = "label34";
            // 
            // CP_1_2
            // 
            this.CP_1_2.AutoSize = true;
            this.CP_1_2.Location = new System.Drawing.Point(211, 128);
            this.CP_1_2.Name = "CP_1_2";
            this.CP_1_2.Size = new System.Drawing.Size(51, 17);
            this.CP_1_2.TabIndex = 3;
            this.CP_1_2.Text = "label34";
            // 
            // lbl_DTMazo1_2
            // 
            this.lbl_DTMazo1_2.AutoSize = true;
            this.lbl_DTMazo1_2.Location = new System.Drawing.Point(211, 44);
            this.lbl_DTMazo1_2.Name = "lbl_DTMazo1_2";
            this.lbl_DTMazo1_2.Size = new System.Drawing.Size(51, 17);
            this.lbl_DTMazo1_2.TabIndex = 3;
            this.lbl_DTMazo1_2.Text = "label34";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(32, 128);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(99, 17);
            this.label12.TabIndex = 1;
            this.label12.Text = "Costo promedio:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(32, 44);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(121, 17);
            this.label9.TabIndex = 1;
            this.label9.Text = "Daño total del mazo:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(32, 166);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(108, 17);
            this.label11.TabIndex = 1;
            this.label11.Text = "Alcance del mazo:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(32, 82);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(116, 17);
            this.label10.TabIndex = 1;
            this.label10.Text = "Vida total del mazo:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Franklin Gothic Medium", 7.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label7.Location = new System.Drawing.Point(60, 15);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(63, 17);
            this.label7.TabIndex = 0;
            this.label7.Text = "Mazos de:";
            // 
            // Mazos_p2
            // 
            this.Mazos_p2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.Mazos_p2.Controls.Add(this.lbl_p1_M);
            this.Mazos_p2.Controls.Add(this.groupBox9);
            this.Mazos_p2.Controls.Add(this.groupBox4);
            this.Mazos_p2.Controls.Add(this.groupBox3);
            this.Mazos_p2.Controls.Add(this.label18);
            this.Mazos_p2.Controls.Add(this.pictureBox4);
            this.Mazos_p2.Controls.Add(this.pictureBox3);
            this.Mazos_p2.Location = new System.Drawing.Point(4, 26);
            this.Mazos_p2.Name = "Mazos_p2";
            this.Mazos_p2.Padding = new System.Windows.Forms.Padding(3);
            this.Mazos_p2.Size = new System.Drawing.Size(1432, 740);
            this.Mazos_p2.TabIndex = 2;
            this.Mazos_p2.Text = "Mazos_P2";
            // 
            // lbl_p1_M
            // 
            this.lbl_p1_M.AutoSize = true;
            this.lbl_p1_M.Font = new System.Drawing.Font("Franklin Gothic Medium", 7.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_p1_M.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lbl_p1_M.Location = new System.Drawing.Point(125, 32);
            this.lbl_p1_M.Name = "lbl_p1_M";
            this.lbl_p1_M.Size = new System.Drawing.Size(21, 17);
            this.lbl_p1_M.TabIndex = 7;
            this.lbl_p1_M.Text = "\" \"";
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.label83);
            this.groupBox9.Controls.Add(this.label84);
            this.groupBox9.Controls.Add(this.label85);
            this.groupBox9.Controls.Add(this.label86);
            this.groupBox9.Controls.Add(this.label87);
            this.groupBox9.Controls.Add(this.label88);
            this.groupBox9.Controls.Add(this.label89);
            this.groupBox9.Controls.Add(this.label90);
            this.groupBox9.Controls.Add(this.label91);
            this.groupBox9.Controls.Add(this.label92);
            this.groupBox9.Controls.Add(this.label93);
            this.groupBox9.Controls.Add(this.label94);
            this.groupBox9.Controls.Add(this.label95);
            this.groupBox9.Controls.Add(this.label96);
            this.groupBox9.Controls.Add(this.label97);
            this.groupBox9.Controls.Add(this.label98);
            this.groupBox9.Controls.Add(this.label99);
            this.groupBox9.Controls.Add(this.label100);
            this.groupBox9.Controls.Add(this.label101);
            this.groupBox9.Controls.Add(this.label102);
            this.groupBox9.Controls.Add(this.label103);
            this.groupBox9.Controls.Add(this.label104);
            this.groupBox9.Controls.Add(this.label105);
            this.groupBox9.Controls.Add(this.label106);
            this.groupBox9.Controls.Add(this.label107);
            this.groupBox9.Controls.Add(this.label108);
            this.groupBox9.Controls.Add(this.label109);
            this.groupBox9.Controls.Add(this.label110);
            this.groupBox9.Font = new System.Drawing.Font("Franklin Gothic Medium", 7.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox9.Location = new System.Drawing.Point(465, 449);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(498, 210);
            this.groupBox9.TabIndex = 6;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Leyenda";
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Location = new System.Drawing.Point(392, 172);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(101, 34);
            this.label83.TabIndex = 6;
            this.label83.Text = "menor que 2.4 o\r\n mayor que 4.3";
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Location = new System.Drawing.Point(217, 171);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(59, 17);
            this.label84.TabIndex = 6;
            this.label84.Text = "3.1 a 3.5";
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Location = new System.Drawing.Point(309, 171);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(59, 17);
            this.label85.TabIndex = 6;
            this.label85.Text = "3.6 a 4.3";
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Location = new System.Drawing.Point(392, 137);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(88, 17);
            this.label86.TabIndex = 6;
            this.label86.Text = "menor que 10";
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Location = new System.Drawing.Point(217, 136);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(53, 17);
            this.label87.TabIndex = 6;
            this.label87.Text = "15 a 25";
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Location = new System.Drawing.Point(309, 136);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(53, 17);
            this.label88.TabIndex = 6;
            this.label88.Text = "10 a 15";
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Location = new System.Drawing.Point(388, 19);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(36, 17);
            this.label89.TabIndex = 4;
            this.label89.Text = "Rojo:";
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Location = new System.Drawing.Point(309, 102);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(85, 17);
            this.label90.TabIndex = 6;
            this.label90.Text = "2000 a 2500";
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Location = new System.Drawing.Point(94, 102);
            this.label91.Name = "label91";
            this.label91.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label91.Size = new System.Drawing.Size(103, 17);
            this.label91.TabIndex = 6;
            this.label91.Text = "mayor que 3000";
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Location = new System.Drawing.Point(111, 18);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(44, 17);
            this.label92.TabIndex = 4;
            this.label92.Text = "Verde:";
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Location = new System.Drawing.Point(209, 102);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(85, 17);
            this.label93.TabIndex = 6;
            this.label93.Text = "2500 a 3000";
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.ForeColor = System.Drawing.Color.Maroon;
            this.label94.Location = new System.Drawing.Point(392, 44);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(33, 17);
            this.label94.TabIndex = 4;
            this.label94.Text = "Bajo";
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Location = new System.Drawing.Point(392, 102);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(104, 17);
            this.label95.TabIndex = 6;
            this.label95.Text = "menor que 2000";
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.ForeColor = System.Drawing.Color.Olive;
            this.label96.Location = new System.Drawing.Point(309, 43);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(54, 17);
            this.label96.TabIndex = 4;
            this.label96.Text = "Decente";
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Location = new System.Drawing.Point(301, 18);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(58, 17);
            this.label97.TabIndex = 4;
            this.label97.Text = "Amarillo:";
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.Location = new System.Drawing.Point(206, 18);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(75, 17);
            this.label98.TabIndex = 4;
            this.label98.Text = "Verde claro:";
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.ForeColor = System.Drawing.Color.Lime;
            this.label99.Location = new System.Drawing.Point(206, 43);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(64, 17);
            this.label99.TabIndex = 4;
            this.label99.Text = "Aceptable";
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.ForeColor = System.Drawing.Color.Green;
            this.label100.Location = new System.Drawing.Point(94, 43);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(75, 17);
            this.label100.TabIndex = 4;
            this.label100.Text = "Inmejorable";
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.Location = new System.Drawing.Point(392, 69);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(104, 17);
            this.label101.TabIndex = 6;
            this.label101.Text = "menor que 2500";
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.Location = new System.Drawing.Point(209, 69);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(85, 17);
            this.label102.TabIndex = 6;
            this.label102.Text = "3000 a 4000";
            // 
            // label103
            // 
            this.label103.AutoSize = true;
            this.label103.Location = new System.Drawing.Point(309, 69);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(85, 17);
            this.label103.TabIndex = 6;
            this.label103.Text = "2500 a 3000";
            // 
            // label104
            // 
            this.label104.AutoSize = true;
            this.label104.Location = new System.Drawing.Point(22, 102);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(37, 17);
            this.label104.TabIndex = 6;
            this.label104.Text = "Daño";
            // 
            // label105
            // 
            this.label105.AutoSize = true;
            this.label105.Location = new System.Drawing.Point(94, 171);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(76, 17);
            this.label105.TabIndex = 6;
            this.label105.Text = "de 2.4 a 3.0";
            // 
            // label106
            // 
            this.label106.AutoSize = true;
            this.label106.Location = new System.Drawing.Point(94, 69);
            this.label106.Name = "label106";
            this.label106.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label106.Size = new System.Drawing.Size(103, 17);
            this.label106.TabIndex = 6;
            this.label106.Text = "mayor que 4000";
            // 
            // label107
            // 
            this.label107.AutoSize = true;
            this.label107.Location = new System.Drawing.Point(91, 136);
            this.label107.Name = "label107";
            this.label107.Size = new System.Drawing.Size(87, 17);
            this.label107.TabIndex = 6;
            this.label107.Text = "mayor que 25";
            // 
            // label108
            // 
            this.label108.AutoSize = true;
            this.label108.Location = new System.Drawing.Point(22, 171);
            this.label108.Name = "label108";
            this.label108.Size = new System.Drawing.Size(39, 17);
            this.label108.TabIndex = 5;
            this.label108.Text = "Costo";
            // 
            // label109
            // 
            this.label109.AutoSize = true;
            this.label109.Location = new System.Drawing.Point(22, 136);
            this.label109.Name = "label109";
            this.label109.Size = new System.Drawing.Size(52, 17);
            this.label109.TabIndex = 5;
            this.label109.Text = "Alcance";
            // 
            // label110
            // 
            this.label110.AutoSize = true;
            this.label110.Location = new System.Drawing.Point(22, 69);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(32, 17);
            this.label110.TabIndex = 5;
            this.label110.Text = "Vida";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btn_esqueletos);
            this.groupBox4.Controls.Add(this.lblalcance4);
            this.groupBox4.Controls.Add(this.cp_4);
            this.groupBox4.Controls.Add(this.lbl_vida4);
            this.groupBox4.Controls.Add(this.label22);
            this.groupBox4.Controls.Add(this.lbl_danio4);
            this.groupBox4.Controls.Add(this.label23);
            this.groupBox4.Controls.Add(this.label24);
            this.groupBox4.Controls.Add(this.label25);
            this.groupBox4.Font = new System.Drawing.Font("Franklin Gothic Medium", 7.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.groupBox4.Location = new System.Drawing.Point(38, 449);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(396, 210);
            this.groupBox4.TabIndex = 4;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Mass esquletos";
            // 
            // btn_esqueletos
            // 
            this.btn_esqueletos.BackColor = System.Drawing.Color.Ivory;
            this.btn_esqueletos.ForeColor = System.Drawing.Color.DarkViolet;
            this.btn_esqueletos.Location = new System.Drawing.Point(298, 37);
            this.btn_esqueletos.Name = "btn_esqueletos";
            this.btn_esqueletos.Size = new System.Drawing.Size(75, 42);
            this.btn_esqueletos.TabIndex = 4;
            this.btn_esqueletos.Text = "Elegir";
            this.btn_esqueletos.UseVisualStyleBackColor = false;
            this.btn_esqueletos.Click += new System.EventHandler(this.btn_esqueletos_Click);
            // 
            // lblalcance4
            // 
            this.lblalcance4.AutoSize = true;
            this.lblalcance4.Location = new System.Drawing.Point(208, 166);
            this.lblalcance4.Name = "lblalcance4";
            this.lblalcance4.Size = new System.Drawing.Size(51, 17);
            this.lblalcance4.TabIndex = 3;
            this.lblalcance4.Text = "label26";
            // 
            // cp_4
            // 
            this.cp_4.AutoSize = true;
            this.cp_4.Location = new System.Drawing.Point(208, 128);
            this.cp_4.Name = "cp_4";
            this.cp_4.Size = new System.Drawing.Size(51, 17);
            this.cp_4.TabIndex = 3;
            this.cp_4.Text = "label26";
            // 
            // lbl_vida4
            // 
            this.lbl_vida4.AutoSize = true;
            this.lbl_vida4.Location = new System.Drawing.Point(208, 82);
            this.lbl_vida4.Name = "lbl_vida4";
            this.lbl_vida4.Size = new System.Drawing.Size(51, 17);
            this.lbl_vida4.TabIndex = 3;
            this.lbl_vida4.Text = "label26";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(32, 128);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(99, 17);
            this.label22.TabIndex = 1;
            this.label22.Text = "Costo promedio:";
            // 
            // lbl_danio4
            // 
            this.lbl_danio4.AutoSize = true;
            this.lbl_danio4.Location = new System.Drawing.Point(208, 44);
            this.lbl_danio4.Name = "lbl_danio4";
            this.lbl_danio4.Size = new System.Drawing.Size(51, 17);
            this.lbl_danio4.TabIndex = 3;
            this.lbl_danio4.Text = "label26";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(32, 44);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(121, 17);
            this.label23.TabIndex = 1;
            this.label23.Text = "Daño total del mazo:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(32, 166);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(108, 17);
            this.label24.TabIndex = 1;
            this.label24.Text = "Alcance del mazo:";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(32, 82);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(116, 17);
            this.label25.TabIndex = 1;
            this.label25.Text = "Vida total del mazo:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btn_helado);
            this.groupBox3.Controls.Add(this.lbl_alcancemazo2_1);
            this.groupBox3.Controls.Add(this.CP_2_1);
            this.groupBox3.Controls.Add(this.Lbl_vidaMazo2_1);
            this.groupBox3.Controls.Add(this.lbl_DTMazo2_1);
            this.groupBox3.Controls.Add(this.label17);
            this.groupBox3.Controls.Add(this.label19);
            this.groupBox3.Controls.Add(this.label20);
            this.groupBox3.Controls.Add(this.label21);
            this.groupBox3.Font = new System.Drawing.Font("Franklin Gothic Medium", 7.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.groupBox3.Location = new System.Drawing.Point(983, 449);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(403, 210);
            this.groupBox3.TabIndex = 3;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Globo helado";
            // 
            // btn_helado
            // 
            this.btn_helado.BackColor = System.Drawing.Color.Ivory;
            this.btn_helado.ForeColor = System.Drawing.Color.DarkViolet;
            this.btn_helado.Location = new System.Drawing.Point(307, 37);
            this.btn_helado.Name = "btn_helado";
            this.btn_helado.Size = new System.Drawing.Size(75, 42);
            this.btn_helado.TabIndex = 4;
            this.btn_helado.Text = "Elegir";
            this.btn_helado.UseVisualStyleBackColor = false;
            this.btn_helado.Click += new System.EventHandler(this.btn_helado_Click);
            // 
            // lbl_alcancemazo2_1
            // 
            this.lbl_alcancemazo2_1.AutoSize = true;
            this.lbl_alcancemazo2_1.Location = new System.Drawing.Point(210, 166);
            this.lbl_alcancemazo2_1.Name = "lbl_alcancemazo2_1";
            this.lbl_alcancemazo2_1.Size = new System.Drawing.Size(51, 17);
            this.lbl_alcancemazo2_1.TabIndex = 3;
            this.lbl_alcancemazo2_1.Text = "label26";
            // 
            // CP_2_1
            // 
            this.CP_2_1.AutoSize = true;
            this.CP_2_1.Location = new System.Drawing.Point(210, 128);
            this.CP_2_1.Name = "CP_2_1";
            this.CP_2_1.Size = new System.Drawing.Size(51, 17);
            this.CP_2_1.TabIndex = 3;
            this.CP_2_1.Text = "label26";
            // 
            // Lbl_vidaMazo2_1
            // 
            this.Lbl_vidaMazo2_1.AutoSize = true;
            this.Lbl_vidaMazo2_1.Location = new System.Drawing.Point(210, 82);
            this.Lbl_vidaMazo2_1.Name = "Lbl_vidaMazo2_1";
            this.Lbl_vidaMazo2_1.Size = new System.Drawing.Size(51, 17);
            this.Lbl_vidaMazo2_1.TabIndex = 3;
            this.Lbl_vidaMazo2_1.Text = "label26";
            // 
            // lbl_DTMazo2_1
            // 
            this.lbl_DTMazo2_1.AutoSize = true;
            this.lbl_DTMazo2_1.Location = new System.Drawing.Point(210, 44);
            this.lbl_DTMazo2_1.Name = "lbl_DTMazo2_1";
            this.lbl_DTMazo2_1.Size = new System.Drawing.Size(51, 17);
            this.lbl_DTMazo2_1.TabIndex = 3;
            this.lbl_DTMazo2_1.Text = "label26";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(32, 128);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(99, 17);
            this.label17.TabIndex = 1;
            this.label17.Text = "Costo promedio:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(32, 44);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(121, 17);
            this.label19.TabIndex = 1;
            this.label19.Text = "Daño total del mazo:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(32, 166);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(108, 17);
            this.label20.TabIndex = 1;
            this.label20.Text = "Alcance del mazo:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(32, 82);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(116, 17);
            this.label21.TabIndex = 1;
            this.label21.Text = "Vida total del mazo:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Franklin Gothic Medium", 7.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label18.Location = new System.Drawing.Point(35, 32);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(63, 17);
            this.label18.TabIndex = 2;
            this.label18.Text = "Mazos de:";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::Proyecto_Final_Walter_Melendez.Properties.Resources.Globo_helado;
            this.pictureBox4.Location = new System.Drawing.Point(759, 51);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(501, 310);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox4.TabIndex = 5;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::Proyecto_Final_Walter_Melendez.Properties.Resources.Mass_Esqueletos;
            this.pictureBox3.Location = new System.Drawing.Point(38, 51);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(494, 314);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox3.TabIndex = 5;
            this.pictureBox3.TabStop = false;
            // 
            // Enfrentamiento_
            // 
            this.Enfrentamiento_.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.Enfrentamiento_.Controls.Add(this.label62);
            this.Enfrentamiento_.Controls.Add(this.groupBox7);
            this.Enfrentamiento_.Controls.Add(this.label27);
            this.Enfrentamiento_.Controls.Add(this.label26);
            this.Enfrentamiento_.Controls.Add(this.Lblmazo_P1);
            this.Enfrentamiento_.Controls.Add(this.lbl_mazo_P2);
            this.Enfrentamiento_.Controls.Add(this.label36);
            this.Enfrentamiento_.Controls.Add(this.lbl_frente2);
            this.Enfrentamiento_.Controls.Add(this.lbl_frente1);
            this.Enfrentamiento_.Location = new System.Drawing.Point(4, 26);
            this.Enfrentamiento_.Name = "Enfrentamiento_";
            this.Enfrentamiento_.Padding = new System.Windows.Forms.Padding(3);
            this.Enfrentamiento_.Size = new System.Drawing.Size(1432, 740);
            this.Enfrentamiento_.TabIndex = 3;
            this.Enfrentamiento_.Text = "Enfrentamiento";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label62.ForeColor = System.Drawing.Color.DarkCyan;
            this.label62.Location = new System.Drawing.Point(46, 587);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(816, 23);
            this.label62.TabIndex = 5;
            this.label62.Text = "Nota: Todos las carateristicas se mediran por cual es el mayor, pero en el caso d" +
    "el costo promedio, el granador será el menor.";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.btn_limpiar);
            this.groupBox7.Controls.Add(this.Ganador);
            this.groupBox7.Controls.Add(this.total_p1);
            this.groupBox7.Controls.Add(this.total_P2);
            this.groupBox7.Controls.Add(this.label61);
            this.groupBox7.Controls.Add(this.lbl_PuntoC1);
            this.groupBox7.Controls.Add(this.lblfrenteC);
            this.groupBox7.Controls.Add(this.lblfrenteC2);
            this.groupBox7.Controls.Add(this.lbl_PuntoC2);
            this.groupBox7.Controls.Add(this.label68);
            this.groupBox7.Controls.Add(this.label60);
            this.groupBox7.Controls.Add(this.lbl_PuntoAl1);
            this.groupBox7.Controls.Add(this.lbl_PuntoV1);
            this.groupBox7.Controls.Add(this.btnEmpezar);
            this.groupBox7.Controls.Add(this.lblfrenteAl1);
            this.groupBox7.Controls.Add(this.lblfrenteV1);
            this.groupBox7.Controls.Add(this.lblfrenteAl2);
            this.groupBox7.Controls.Add(this.lblfrenteV2);
            this.groupBox7.Controls.Add(this.lbl_PuntoAl2);
            this.groupBox7.Controls.Add(this.label82);
            this.groupBox7.Controls.Add(this.lbl_PuntoM1);
            this.groupBox7.Controls.Add(this.label77);
            this.groupBox7.Controls.Add(this.lbl_PuntoV2);
            this.groupBox7.Controls.Add(this.lblfrenteM1);
            this.groupBox7.Controls.Add(this.lblfrenteM2);
            this.groupBox7.Controls.Add(this.label67);
            this.groupBox7.Controls.Add(this.label59);
            this.groupBox7.Controls.Add(this.label66);
            this.groupBox7.Controls.Add(this.lbl_PuntoM2);
            this.groupBox7.Controls.Add(this.label65);
            this.groupBox7.Controls.Add(this.label58);
            this.groupBox7.Controls.Add(this.label57);
            this.groupBox7.Font = new System.Drawing.Font("Franklin Gothic Medium", 7.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox7.Location = new System.Drawing.Point(61, 121);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(1115, 362);
            this.groupBox7.TabIndex = 4;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Putuación";
            // 
            // Ganador
            // 
            this.Ganador.AutoSize = true;
            this.Ganador.Location = new System.Drawing.Point(549, 330);
            this.Ganador.Name = "Ganador";
            this.Ganador.Size = new System.Drawing.Size(51, 17);
            this.Ganador.TabIndex = 2;
            this.Ganador.Text = "label63";
            // 
            // total_p1
            // 
            this.total_p1.AutoSize = true;
            this.total_p1.Location = new System.Drawing.Point(428, 277);
            this.total_p1.Name = "total_p1";
            this.total_p1.Size = new System.Drawing.Size(51, 17);
            this.total_p1.TabIndex = 1;
            this.total_p1.Text = "label57";
            // 
            // total_P2
            // 
            this.total_P2.AutoSize = true;
            this.total_P2.Location = new System.Drawing.Point(662, 277);
            this.total_P2.Name = "total_P2";
            this.total_P2.Size = new System.Drawing.Size(51, 17);
            this.total_P2.TabIndex = 1;
            this.total_P2.Text = "label57";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(526, 236);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(93, 17);
            this.label61.TabIndex = 1;
            this.label61.Text = "Total de puntos";
            // 
            // lbl_PuntoC1
            // 
            this.lbl_PuntoC1.AutoSize = true;
            this.lbl_PuntoC1.Location = new System.Drawing.Point(317, 195);
            this.lbl_PuntoC1.Name = "lbl_PuntoC1";
            this.lbl_PuntoC1.Size = new System.Drawing.Size(16, 17);
            this.lbl_PuntoC1.TabIndex = 1;
            this.lbl_PuntoC1.Text = "0";
            // 
            // lblfrenteC
            // 
            this.lblfrenteC.AutoSize = true;
            this.lblfrenteC.Location = new System.Drawing.Point(201, 195);
            this.lblfrenteC.Name = "lblfrenteC";
            this.lblfrenteC.Size = new System.Drawing.Size(51, 17);
            this.lblfrenteC.TabIndex = 1;
            this.lblfrenteC.Text = "label57";
            // 
            // lblfrenteC2
            // 
            this.lblfrenteC2.AutoSize = true;
            this.lblfrenteC2.Location = new System.Drawing.Point(873, 195);
            this.lblfrenteC2.Name = "lblfrenteC2";
            this.lblfrenteC2.Size = new System.Drawing.Size(51, 17);
            this.lblfrenteC2.TabIndex = 1;
            this.lblfrenteC2.Text = "label57";
            // 
            // lbl_PuntoC2
            // 
            this.lbl_PuntoC2.AutoSize = true;
            this.lbl_PuntoC2.Location = new System.Drawing.Point(764, 195);
            this.lbl_PuntoC2.Name = "lbl_PuntoC2";
            this.lbl_PuntoC2.Size = new System.Drawing.Size(16, 17);
            this.lbl_PuntoC2.TabIndex = 1;
            this.lbl_PuntoC2.Text = "0";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(1030, 195);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(39, 17);
            this.label68.TabIndex = 1;
            this.label68.Text = "Costo";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(91, 195);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(39, 17);
            this.label60.TabIndex = 1;
            this.label60.Text = "Costo";
            // 
            // lbl_PuntoAl1
            // 
            this.lbl_PuntoAl1.AutoSize = true;
            this.lbl_PuntoAl1.Location = new System.Drawing.Point(317, 148);
            this.lbl_PuntoAl1.Name = "lbl_PuntoAl1";
            this.lbl_PuntoAl1.Size = new System.Drawing.Size(16, 17);
            this.lbl_PuntoAl1.TabIndex = 1;
            this.lbl_PuntoAl1.Text = "0";
            // 
            // lbl_PuntoV1
            // 
            this.lbl_PuntoV1.AutoSize = true;
            this.lbl_PuntoV1.Location = new System.Drawing.Point(317, 111);
            this.lbl_PuntoV1.Name = "lbl_PuntoV1";
            this.lbl_PuntoV1.Size = new System.Drawing.Size(16, 17);
            this.lbl_PuntoV1.TabIndex = 1;
            this.lbl_PuntoV1.Text = "0";
            // 
            // btnEmpezar
            // 
            this.btnEmpezar.BackColor = System.Drawing.Color.Ivory;
            this.btnEmpezar.Font = new System.Drawing.Font("Franklin Gothic Medium", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEmpezar.ForeColor = System.Drawing.Color.DarkViolet;
            this.btnEmpezar.Location = new System.Drawing.Point(514, 148);
            this.btnEmpezar.Name = "btnEmpezar";
            this.btnEmpezar.Size = new System.Drawing.Size(134, 58);
            this.btnEmpezar.TabIndex = 0;
            this.btnEmpezar.Text = "Empezar";
            this.btnEmpezar.UseVisualStyleBackColor = false;
            this.btnEmpezar.Click += new System.EventHandler(this.btnEmpezar_Click);
            // 
            // lblfrenteAl1
            // 
            this.lblfrenteAl1.AutoSize = true;
            this.lblfrenteAl1.Location = new System.Drawing.Point(201, 148);
            this.lblfrenteAl1.Name = "lblfrenteAl1";
            this.lblfrenteAl1.Size = new System.Drawing.Size(51, 17);
            this.lblfrenteAl1.TabIndex = 1;
            this.lblfrenteAl1.Text = "label57";
            // 
            // lblfrenteV1
            // 
            this.lblfrenteV1.AutoSize = true;
            this.lblfrenteV1.Location = new System.Drawing.Point(201, 111);
            this.lblfrenteV1.Name = "lblfrenteV1";
            this.lblfrenteV1.Size = new System.Drawing.Size(51, 17);
            this.lblfrenteV1.TabIndex = 1;
            this.lblfrenteV1.Text = "label57";
            // 
            // lblfrenteAl2
            // 
            this.lblfrenteAl2.AutoSize = true;
            this.lblfrenteAl2.Location = new System.Drawing.Point(873, 148);
            this.lblfrenteAl2.Name = "lblfrenteAl2";
            this.lblfrenteAl2.Size = new System.Drawing.Size(51, 17);
            this.lblfrenteAl2.TabIndex = 1;
            this.lblfrenteAl2.Text = "label57";
            // 
            // lblfrenteV2
            // 
            this.lblfrenteV2.AutoSize = true;
            this.lblfrenteV2.Location = new System.Drawing.Point(873, 111);
            this.lblfrenteV2.Name = "lblfrenteV2";
            this.lblfrenteV2.Size = new System.Drawing.Size(51, 17);
            this.lblfrenteV2.TabIndex = 1;
            this.lblfrenteV2.Text = "label57";
            // 
            // lbl_PuntoAl2
            // 
            this.lbl_PuntoAl2.AutoSize = true;
            this.lbl_PuntoAl2.Location = new System.Drawing.Point(764, 148);
            this.lbl_PuntoAl2.Name = "lbl_PuntoAl2";
            this.lbl_PuntoAl2.Size = new System.Drawing.Size(16, 17);
            this.lbl_PuntoAl2.TabIndex = 1;
            this.lbl_PuntoAl2.Text = "0";
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Location = new System.Drawing.Point(764, 32);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(47, 17);
            this.label82.TabIndex = 1;
            this.label82.Text = "Puntos";
            // 
            // lbl_PuntoM1
            // 
            this.lbl_PuntoM1.AutoSize = true;
            this.lbl_PuntoM1.Location = new System.Drawing.Point(317, 69);
            this.lbl_PuntoM1.Name = "lbl_PuntoM1";
            this.lbl_PuntoM1.Size = new System.Drawing.Size(16, 17);
            this.lbl_PuntoM1.TabIndex = 1;
            this.lbl_PuntoM1.Text = "0";
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Location = new System.Drawing.Point(317, 32);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(47, 17);
            this.label77.TabIndex = 1;
            this.label77.Text = "Puntos";
            // 
            // lbl_PuntoV2
            // 
            this.lbl_PuntoV2.AutoSize = true;
            this.lbl_PuntoV2.Location = new System.Drawing.Point(764, 111);
            this.lbl_PuntoV2.Name = "lbl_PuntoV2";
            this.lbl_PuntoV2.Size = new System.Drawing.Size(16, 17);
            this.lbl_PuntoV2.TabIndex = 1;
            this.lbl_PuntoV2.Text = "0";
            // 
            // lblfrenteM1
            // 
            this.lblfrenteM1.AutoSize = true;
            this.lblfrenteM1.Location = new System.Drawing.Point(201, 69);
            this.lblfrenteM1.Name = "lblfrenteM1";
            this.lblfrenteM1.Size = new System.Drawing.Size(51, 17);
            this.lblfrenteM1.TabIndex = 1;
            this.lblfrenteM1.Text = "label57";
            // 
            // lblfrenteM2
            // 
            this.lblfrenteM2.AutoSize = true;
            this.lblfrenteM2.Location = new System.Drawing.Point(873, 69);
            this.lblfrenteM2.Name = "lblfrenteM2";
            this.lblfrenteM2.Size = new System.Drawing.Size(51, 17);
            this.lblfrenteM2.TabIndex = 1;
            this.lblfrenteM2.Text = "label57";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(1030, 148);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(52, 17);
            this.label67.TabIndex = 1;
            this.label67.Text = "Alcance";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(91, 148);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(52, 17);
            this.label59.TabIndex = 1;
            this.label59.Text = "Alcance";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(1030, 111);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(32, 17);
            this.label66.TabIndex = 1;
            this.label66.Text = "Vida";
            // 
            // lbl_PuntoM2
            // 
            this.lbl_PuntoM2.AutoSize = true;
            this.lbl_PuntoM2.Location = new System.Drawing.Point(764, 69);
            this.lbl_PuntoM2.Name = "lbl_PuntoM2";
            this.lbl_PuntoM2.Size = new System.Drawing.Size(16, 17);
            this.lbl_PuntoM2.TabIndex = 1;
            this.lbl_PuntoM2.Text = "0";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(1030, 69);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(37, 17);
            this.label65.TabIndex = 1;
            this.label65.Text = "Daño";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(91, 111);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(32, 17);
            this.label58.TabIndex = 1;
            this.label58.Text = "Vida";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(91, 69);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(37, 17);
            this.label57.TabIndex = 1;
            this.label57.Text = "Daño";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Franklin Gothic Medium", 13.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label27.Location = new System.Drawing.Point(954, 50);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(68, 29);
            this.label27.TabIndex = 3;
            this.label27.Text = "usará";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Franklin Gothic Medium", 13.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label26.Location = new System.Drawing.Point(194, 50);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(68, 29);
            this.label26.TabIndex = 3;
            this.label26.Text = "usará";
            // 
            // Lblmazo_P1
            // 
            this.Lblmazo_P1.AutoSize = true;
            this.Lblmazo_P1.Font = new System.Drawing.Font("Franklin Gothic Medium", 13.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lblmazo_P1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Lblmazo_P1.Location = new System.Drawing.Point(378, 50);
            this.Lblmazo_P1.Name = "Lblmazo_P1";
            this.Lblmazo_P1.Size = new System.Drawing.Size(87, 29);
            this.Lblmazo_P1.TabIndex = 2;
            this.Lblmazo_P1.Text = "label26";
            // 
            // lbl_mazo_P2
            // 
            this.lbl_mazo_P2.AutoSize = true;
            this.lbl_mazo_P2.Font = new System.Drawing.Font("Franklin Gothic Medium", 13.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_mazo_P2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lbl_mazo_P2.Location = new System.Drawing.Point(776, 50);
            this.lbl_mazo_P2.Name = "lbl_mazo_P2";
            this.lbl_mazo_P2.Size = new System.Drawing.Size(87, 29);
            this.lbl_mazo_P2.TabIndex = 1;
            this.lbl_mazo_P2.Text = "label35";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Franklin Gothic Medium", 13.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(587, 50);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(39, 29);
            this.label36.TabIndex = 0;
            this.label36.Text = "VS";
            // 
            // lbl_frente2
            // 
            this.lbl_frente2.AutoSize = true;
            this.lbl_frente2.Font = new System.Drawing.Font("Franklin Gothic Medium", 13.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_frente2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lbl_frente2.Location = new System.Drawing.Point(58, 50);
            this.lbl_frente2.Name = "lbl_frente2";
            this.lbl_frente2.Size = new System.Drawing.Size(37, 29);
            this.lbl_frente2.TabIndex = 1;
            this.lbl_frente2.Text = "\" \"";
            // 
            // lbl_frente1
            // 
            this.lbl_frente1.AutoSize = true;
            this.lbl_frente1.Font = new System.Drawing.Font("Franklin Gothic Medium", 13.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_frente1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lbl_frente1.Location = new System.Drawing.Point(1156, 50);
            this.lbl_frente1.Name = "lbl_frente1";
            this.lbl_frente1.Size = new System.Drawing.Size(37, 29);
            this.lbl_frente1.TabIndex = 0;
            this.lbl_frente1.Text = "\" \"";
            // 
            // btn_limpiar
            // 
            this.btn_limpiar.ForeColor = System.Drawing.Color.DarkViolet;
            this.btn_limpiar.Location = new System.Drawing.Point(1007, 309);
            this.btn_limpiar.Name = "btn_limpiar";
            this.btn_limpiar.Size = new System.Drawing.Size(75, 23);
            this.btn_limpiar.TabIndex = 3;
            this.btn_limpiar.Text = "Limpiar";
            this.btn_limpiar.UseVisualStyleBackColor = true;
            this.btn_limpiar.Click += new System.EventHandler(this.btn_limpiar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(1452, 794);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tabControl1.ResumeLayout(false);
            this.Inico.ResumeLayout(false);
            this.Inico.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.Mazo_p1.ResumeLayout(false);
            this.Mazo_p1.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.Mazos_p2.ResumeLayout(false);
            this.Mazos_p2.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.Enfrentamiento_.ResumeLayout(false);
            this.Enfrentamiento_.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage Inico;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button Btn_nickanme2;
        private System.Windows.Forms.Button btn_Nicname1;
        private System.Windows.Forms.TextBox Txt_equipo2;
        private System.Windows.Forms.TextBox txt_equipo;
        private System.Windows.Forms.TextBox Txt_nombre2;
        private System.Windows.Forms.TextBox Txt_nombre;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lbl_nick2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbl_nick1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabPage Mazo_p1;
        private System.Windows.Forms.TabPage Mazos_p2;
        private System.Windows.Forms.TabPage Enfrentamiento_;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label lblalcance4;
        private System.Windows.Forms.Label cp_4;
        private System.Windows.Forms.Label lbl_vida4;
        private System.Windows.Forms.Label lbl_danio4;
        private System.Windows.Forms.Label lbl_mazo_P2;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label lbl_frente2;
        private System.Windows.Forms.Label lbl_frente1;
        private System.Windows.Forms.Label lblalcance_mazo_1_1;
        private System.Windows.Forms.Label lbl_VTmazo1_1;
        private System.Windows.Forms.Label CP_1_1;
        private System.Windows.Forms.Label lbl_AlcanceMazo1_2;
        private System.Windows.Forms.Label lbl_VTMazo1_2;
        private System.Windows.Forms.Label CP_1_2;
        private System.Windows.Forms.Label lbl_DTMazo1_2;
        private System.Windows.Forms.Label lbl_DT1_1;
        private System.Windows.Forms.Label lbl_alcancemazo2_1;
        private System.Windows.Forms.Label CP_2_1;
        private System.Windows.Forms.Label Lbl_vidaMazo2_1;
        private System.Windows.Forms.Label lbl_DTMazo2_1;
        private System.Windows.Forms.Label Lblmazo_P1;
        private System.Windows.Forms.Button btn_revelion;
        private System.Windows.Forms.Button btn_boys;
        private System.Windows.Forms.Button btn_esqueletos;
        private System.Windows.Forms.Button btn_helado;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.Label label107;
        private System.Windows.Forms.Label label108;
        private System.Windows.Forms.Label label109;
        private System.Windows.Forms.Label label110;
        private System.Windows.Forms.Label lbl_PuntoC1;
        private System.Windows.Forms.Label lblfrenteC;
        private System.Windows.Forms.Label lblfrenteC2;
        private System.Windows.Forms.Label lbl_PuntoC2;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label lbl_PuntoAl1;
        private System.Windows.Forms.Label lbl_PuntoV1;
        private System.Windows.Forms.Label lblfrenteAl1;
        private System.Windows.Forms.Label lblfrenteV1;
        private System.Windows.Forms.Label lblfrenteAl2;
        private System.Windows.Forms.Label lblfrenteV2;
        private System.Windows.Forms.Label lbl_PuntoAl2;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label lbl_PuntoM1;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label lbl_PuntoV2;
        private System.Windows.Forms.Label lblfrenteM1;
        private System.Windows.Forms.Label lblfrenteM2;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label lbl_PuntoM2;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Button btnEmpezar;
        private System.Windows.Forms.Label total_p1;
        private System.Windows.Forms.Label total_P2;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label Ganador;
        private System.Windows.Forms.Label lbl_mazos_p2;
        private System.Windows.Forms.Label lbl_p1_M;
        private System.Windows.Forms.Button btn_limpiar;
    }
}

