﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L_11._1174722
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /* Console.WriteLine("Ingrese un número mayor a diez");
             int N = int.Parse(Console.ReadLine());

             int[] elemeto = new int[N];
             for (int i = 0; i < N; i++)
             {
                 Console.WriteLine("Ingrese el numero que deseea agregar");
                 int numero = int.Parse(Console.ReadLine()); 
                 elemeto[i] = numero;
             }*/

            Console.WriteLine("Ingrese X:");
            int x = int.Parse(Console.ReadLine());

            Console.WriteLine("Ingrese Y:");
            int y = int.Parse(Console.ReadLine());

            int[,] table = new int[x, y];
            table[0, 1] = 155;

            //Recorrer un areglo multidimensonal
            for (int X = 0; x < X; X++)
            {

                for (int Y = 0; y < Y; Y++)
                {
                    table[x, y] = 1;

                }
            }

            Console.ReadKey();


        }
    }
}
