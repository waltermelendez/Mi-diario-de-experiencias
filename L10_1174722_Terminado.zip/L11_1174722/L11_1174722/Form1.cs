﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace L11_1174722
{
    public partial class Form1 : Form
    {
        Carro nuevoCarro = new Carro();
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCargarDatos_Click(object sender, EventArgs e)
        {


            string MArca = txtMarc.Text;

            int Modelo = (int)NDModelo.Value;

            double precio = (double)NDPrecio.Value;

            string descripcion = RtxtDescripcion.Text;

            nuevoCarro.SetMarca(MArca);
            nuevoCarro.SetPrecio(precio);
            nuevoCarro.SetDescripcion(descripcion);
            nuevoCarro.SetModelo(Modelo);


        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            OutputMarc.Text = nuevoCarro.LeerMarca();
            OutputDescripcion.Text = nuevoCarro.LeerDrescripcion();
            OutputPrecio.Text = nuevoCarro.leePrecio().ToString();
            OutputModelo.Text = nuevoCarro.LeerModelo().ToString();


        }

        private void btnCalcularPrecio_Click(object sender, EventArgs e)
        {
           
            NDIVA.Value = (NDIVA.Value / 100)*NDPrecio.Value;
            OutputPrecioFinal.Text = NDIVA.Value.ToString();
            if (NDIVA.Value == 0)
            {
                OutputPrecioFinal.Text = "Error, ese no es una cantidad para el IVA";

            }
        }
    }






}
