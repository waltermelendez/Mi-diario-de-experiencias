﻿namespace L11_1174722
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.NDIVA = new System.Windows.Forms.NumericUpDown();
            this.btnCalcularPrecio = new System.Windows.Forms.Button();
            this.OutputDescripcion = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.OutputPrecio = new System.Windows.Forms.Label();
            this.OutputPrecioFinal = new System.Windows.Forms.Label();
            this.OutputModelo = new System.Windows.Forms.Label();
            this.OutputMarc = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnActualizar = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btnCargarDatos = new System.Windows.Forms.Button();
            this.RtxtDescripcion = new System.Windows.Forms.RichTextBox();
            this.NDPrecio = new System.Windows.Forms.NumericUpDown();
            this.NDModelo = new System.Windows.Forms.NumericUpDown();
            this.txtMarc = new System.Windows.Forms.TextBox();
            this.lblDescripcion = new System.Windows.Forms.Label();
            this.lblPrecio = new System.Windows.Forms.Label();
            this.lblModelo = new System.Windows.Forms.Label();
            this.lblCarro = new System.Windows.Forms.Label();
            this.lblMarca = new System.Windows.Forms.Label();
            this.EPdatos = new System.Windows.Forms.ErrorProvider(this.components);
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NDIVA)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NDPrecio)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NDModelo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EPdatos)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1003, 590);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.NDIVA);
            this.tabPage1.Controls.Add(this.btnCalcularPrecio);
            this.tabPage1.Controls.Add(this.OutputDescripcion);
            this.tabPage1.Controls.Add(this.label11);
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.label13);
            this.tabPage1.Controls.Add(this.label10);
            this.tabPage1.Controls.Add(this.OutputPrecio);
            this.tabPage1.Controls.Add(this.OutputPrecioFinal);
            this.tabPage1.Controls.Add(this.OutputModelo);
            this.tabPage1.Controls.Add(this.OutputMarc);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.btnActualizar);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(995, 561);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Ver Datos";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // NDIVA
            // 
            this.NDIVA.Location = new System.Drawing.Point(177, 334);
            this.NDIVA.Name = "NDIVA";
            this.NDIVA.Size = new System.Drawing.Size(120, 22);
            this.NDIVA.TabIndex = 3;
            // 
            // btnCalcularPrecio
            // 
            this.btnCalcularPrecio.Location = new System.Drawing.Point(177, 424);
            this.btnCalcularPrecio.Name = "btnCalcularPrecio";
            this.btnCalcularPrecio.Size = new System.Drawing.Size(110, 35);
            this.btnCalcularPrecio.TabIndex = 2;
            this.btnCalcularPrecio.Text = "Calcular Precio";
            this.btnCalcularPrecio.UseVisualStyleBackColor = true;
            this.btnCalcularPrecio.Click += new System.EventHandler(this.btnCalcularPrecio_Click);
            // 
            // OutputDescripcion
            // 
            this.OutputDescripcion.AutoSize = true;
            this.OutputDescripcion.Location = new System.Drawing.Point(187, 268);
            this.OutputDescripcion.Name = "OutputDescripcion";
            this.OutputDescripcion.Size = new System.Drawing.Size(79, 16);
            this.OutputDescripcion.TabIndex = 1;
            this.OutputDescripcion.Text = "Descripcion";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(187, 340);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(0, 16);
            this.label11.TabIndex = 1;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(51, 268);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(44, 16);
            this.label9.TabIndex = 1;
            this.label9.Text = "label1";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(51, 340);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(0, 16);
            this.label8.TabIndex = 1;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(51, 340);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(44, 16);
            this.label13.TabIndex = 1;
            this.label13.Text = "label1";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(51, 496);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(44, 16);
            this.label10.TabIndex = 1;
            this.label10.Text = "label1";
            // 
            // OutputPrecio
            // 
            this.OutputPrecio.AutoSize = true;
            this.OutputPrecio.Location = new System.Drawing.Point(187, 214);
            this.OutputPrecio.Name = "OutputPrecio";
            this.OutputPrecio.Size = new System.Drawing.Size(46, 16);
            this.OutputPrecio.TabIndex = 1;
            this.OutputPrecio.Text = "Precio";
            // 
            // OutputPrecioFinal
            // 
            this.OutputPrecioFinal.AutoSize = true;
            this.OutputPrecioFinal.Location = new System.Drawing.Point(187, 496);
            this.OutputPrecioFinal.Name = "OutputPrecioFinal";
            this.OutputPrecioFinal.Size = new System.Drawing.Size(78, 16);
            this.OutputPrecioFinal.TabIndex = 1;
            this.OutputPrecioFinal.Text = "Precio Final";
            // 
            // OutputModelo
            // 
            this.OutputModelo.AutoSize = true;
            this.OutputModelo.Location = new System.Drawing.Point(187, 162);
            this.OutputModelo.Name = "OutputModelo";
            this.OutputModelo.Size = new System.Drawing.Size(53, 16);
            this.OutputModelo.TabIndex = 1;
            this.OutputModelo.Text = "Modelo";
            // 
            // OutputMarc
            // 
            this.OutputMarc.AutoSize = true;
            this.OutputMarc.Location = new System.Drawing.Point(187, 113);
            this.OutputMarc.Name = "OutputMarc";
            this.OutputMarc.Size = new System.Drawing.Size(45, 16);
            this.OutputMarc.TabIndex = 1;
            this.OutputMarc.Text = "Marca";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(51, 162);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 16);
            this.label3.TabIndex = 1;
            this.label3.Text = "label1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(51, 113);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "label1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(51, 214);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "label1";
            // 
            // btnActualizar
            // 
            this.btnActualizar.Location = new System.Drawing.Point(36, 15);
            this.btnActualizar.Name = "btnActualizar";
            this.btnActualizar.Size = new System.Drawing.Size(929, 79);
            this.btnActualizar.TabIndex = 0;
            this.btnActualizar.Text = "Actualizar";
            this.btnActualizar.UseVisualStyleBackColor = true;
            this.btnActualizar.Click += new System.EventHandler(this.btnActualizar_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.btnCargarDatos);
            this.tabPage2.Controls.Add(this.RtxtDescripcion);
            this.tabPage2.Controls.Add(this.NDPrecio);
            this.tabPage2.Controls.Add(this.NDModelo);
            this.tabPage2.Controls.Add(this.txtMarc);
            this.tabPage2.Controls.Add(this.lblDescripcion);
            this.tabPage2.Controls.Add(this.lblPrecio);
            this.tabPage2.Controls.Add(this.lblModelo);
            this.tabPage2.Controls.Add(this.lblCarro);
            this.tabPage2.Controls.Add(this.lblMarca);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(995, 561);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Ingreso de Datos";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // btnCargarDatos
            // 
            this.btnCargarDatos.Location = new System.Drawing.Point(219, 403);
            this.btnCargarDatos.Name = "btnCargarDatos";
            this.btnCargarDatos.Size = new System.Drawing.Size(237, 64);
            this.btnCargarDatos.TabIndex = 4;
            this.btnCargarDatos.Text = "Cargar Datos";
            this.btnCargarDatos.UseVisualStyleBackColor = true;
            this.btnCargarDatos.Click += new System.EventHandler(this.btnCargarDatos_Click);
            // 
            // RtxtDescripcion
            // 
            this.RtxtDescripcion.Location = new System.Drawing.Point(219, 270);
            this.RtxtDescripcion.Name = "RtxtDescripcion";
            this.RtxtDescripcion.Size = new System.Drawing.Size(347, 67);
            this.RtxtDescripcion.TabIndex = 3;
            this.RtxtDescripcion.Text = "";
            // 
            // NDPrecio
            // 
            this.NDPrecio.Location = new System.Drawing.Point(219, 187);
            this.NDPrecio.Name = "NDPrecio";
            this.NDPrecio.Size = new System.Drawing.Size(306, 22);
            this.NDPrecio.TabIndex = 2;
            // 
            // NDModelo
            // 
            this.NDModelo.Location = new System.Drawing.Point(219, 126);
            this.NDModelo.Name = "NDModelo";
            this.NDModelo.Size = new System.Drawing.Size(306, 22);
            this.NDModelo.TabIndex = 2;
            // 
            // txtMarc
            // 
            this.txtMarc.Location = new System.Drawing.Point(219, 69);
            this.txtMarc.Name = "txtMarc";
            this.txtMarc.Size = new System.Drawing.Size(306, 22);
            this.txtMarc.TabIndex = 1;
            // 
            // lblDescripcion
            // 
            this.lblDescripcion.AutoSize = true;
            this.lblDescripcion.Location = new System.Drawing.Point(76, 273);
            this.lblDescripcion.Name = "lblDescripcion";
            this.lblDescripcion.Size = new System.Drawing.Size(79, 16);
            this.lblDescripcion.TabIndex = 0;
            this.lblDescripcion.Text = "Descripcion";
            // 
            // lblPrecio
            // 
            this.lblPrecio.AutoSize = true;
            this.lblPrecio.Location = new System.Drawing.Point(76, 193);
            this.lblPrecio.Name = "lblPrecio";
            this.lblPrecio.Size = new System.Drawing.Size(46, 16);
            this.lblPrecio.TabIndex = 0;
            this.lblPrecio.Text = "Precio";
            // 
            // lblModelo
            // 
            this.lblModelo.AutoSize = true;
            this.lblModelo.Location = new System.Drawing.Point(76, 108);
            this.lblModelo.Name = "lblModelo";
            this.lblModelo.Size = new System.Drawing.Size(53, 16);
            this.lblModelo.TabIndex = 0;
            this.lblModelo.Text = "Modelo";
            // 
            // lblCarro
            // 
            this.lblCarro.AutoSize = true;
            this.lblCarro.Location = new System.Drawing.Point(18, 17);
            this.lblCarro.Name = "lblCarro";
            this.lblCarro.Size = new System.Drawing.Size(40, 16);
            this.lblCarro.TabIndex = 0;
            this.lblCarro.Text = "Carro";
            // 
            // lblMarca
            // 
            this.lblMarca.AutoSize = true;
            this.lblMarca.Location = new System.Drawing.Point(76, 60);
            this.lblMarca.Name = "lblMarca";
            this.lblMarca.Size = new System.Drawing.Size(45, 16);
            this.lblMarca.TabIndex = 0;
            this.lblMarca.Text = "Marca";
            // 
            // EPdatos
            // 
            this.EPdatos.ContainerControl = this;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1027, 605);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NDIVA)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NDPrecio)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NDModelo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EPdatos)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button btnCalcularPrecio;
        private System.Windows.Forms.Label OutputDescripcion;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label OutputPrecio;
        private System.Windows.Forms.Label OutputPrecioFinal;
        private System.Windows.Forms.Label OutputModelo;
        private System.Windows.Forms.Label OutputMarc;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnActualizar;
        private System.Windows.Forms.TextBox txtMarc;
        private System.Windows.Forms.Label lblDescripcion;
        private System.Windows.Forms.Label lblPrecio;
        private System.Windows.Forms.Label lblModelo;
        private System.Windows.Forms.Label lblMarca;
        private System.Windows.Forms.Button btnCargarDatos;
        private System.Windows.Forms.RichTextBox RtxtDescripcion;
        private System.Windows.Forms.NumericUpDown NDPrecio;
        private System.Windows.Forms.NumericUpDown NDModelo;
        private System.Windows.Forms.Label lblCarro;
        private System.Windows.Forms.NumericUpDown NDIVA;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ErrorProvider EPdatos;
    }
}

