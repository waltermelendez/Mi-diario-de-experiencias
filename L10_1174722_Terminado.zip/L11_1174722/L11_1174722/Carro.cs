﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L11_1174722
{
    internal class Carro
    {
        private string Marca = "";
        private int Modelo = 0;
        private double Precio = 0;
        private string Descripcion = "";
        private double IVa = 0;

        public void SetMarca(string marca)
        {
            if (marca != "")
            {
                this.Marca = marca;
            }
        }

        public void SetModelo(int MOdelo)
        {
            this.Modelo = MOdelo;
        }

        public void SetPrecio(double precio)
        {
            this.Precio = precio;
        }

        public void SetDescripcion(string desc)
        {
            this.Descripcion = desc;
        }

        public string LeerMarca()
        {
            return Marca;
        }

        public int LeerModelo()
        {
            return this.Modelo;
        }

        public double leePrecio()
        {
            return this.Precio;
        }

        public string LeerDrescripcion()
        {
            return this.Descripcion;
        }

        public double SetIVA(int IVAD) => this.IVa = IVAD;
       

        public double DarIVA()
        {
            return this.IVa;
        }
    }
}
